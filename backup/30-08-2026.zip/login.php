<?php 
require_once __DIR__.'/includes/auth.php'; 
if(u()) header('Location:'.url('/')); 
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = db()->prepare('SELECT * FROM users WHERE email=? AND status="active"');
    $s->execute([$_POST['email']]);
    $x = $s->fetch();
    if ($x && password_verify($_POST['password'], $x['password'])) {
        login($x);
        header('Location:'.url('/'));
        exit;
    }
    $err = 'Invalid email or password credentials.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login · FinStore Pay ERP</title>
    
    <!-- Google Fonts & Lucide Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>

    <link rel="stylesheet" href="<?=url('/public/assets/css/app.css')?>">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .login-card {
            width: 100%;
            max-width: 440px;
            background: var(--bg-card);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
        }
        .login-header {
            text-align: center;
            margin-bottom: 28px;
        }
        .login-header .logo {
            width: 52px;
            height: 52px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.4rem;
            color: #fff;
            margin: 0 auto 16px auto;
            box-shadow: 0 4px 20px var(--primary-glow);
        }
        .login-header h1 {
            font-size: 1.6rem;
            font-weight: 800;
            color: #fff;
        }
        .login-header p {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-top: 4px;
        }
        .alert-danger {
            background: var(--danger-bg);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--danger);
            padding: 12px 16px;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="login-header">
            <div class="logo">FS</div>
            <h1>FinStore <span>Pay</span></h1>
            <p>Enter your credentials to access your ERP portal</p>
        </div>

        <?php if($err): ?>
            <div class="alert-danger"><?=$err?></div>
        <?php endif; ?>

        <form method="post">
            <div class="field">
                <label>Email Address</label>
                <input name="email" type="email" placeholder="e.g. superadmin@example.com" required>
            </div>
            <div class="field">
                <label>Password</label>
                <input name="password" type="password" placeholder="••••••••" required>
            </div>
            <button class="btn" style="width: 100%; margin-top: 10px; padding: 14px;">
                <i data-lucide="log-in"></i> Sign In to Portal
            </button>
        </form>

        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--border-color); font-size: 0.78rem; color: var(--text-muted); text-align: center;">
            Demo Admin: <strong style="color: #fff;">superadmin@example.com</strong> / <strong style="color: #fff;">password</strong>
        </div>
    </div>

    <script>
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    </script>
</body>
</html>
