<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

define('DB_HOST', 'localhost');
define('DB_NAME', 'go4fin');
define('DB_USER', 'root');
define('DB_PASS', '');

// PayU Payment Gateway Config
define('PAYU_MERCHANT_KEY', 'JLFa4D');
define('PAYU_SALT', 'BdsRuvcWukuapuJTrlAL0McodEVT2DMl');
define('PAYU_ENV', 'production'); // Change to 'production' for live payments
define('PAYU_BASE_URL', PAYU_ENV === 'production' ? 'https://secure.payu.in/_payment' : 'https://test.payu.in/_payment');

// Dynamically determine BASE_URL
$docRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');
$appDir = str_replace('\\', '/', realpath(__DIR__ . '/..') ?: '');

if (!empty($docRoot) && !empty($appDir) && strpos($appDir, $docRoot) === 0) {
    $baseUrl = substr($appDir, strlen($docRoot));
} else {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $pos = strpos($script, '/soft');
    if ($pos !== false) {
        $baseUrl = substr($script, 0, $pos + 5);
    } else {
        $baseUrl = dirname($script);
    }
}

$baseUrl = '/' . ltrim(str_replace('\\', '/', $baseUrl), '/');
$baseUrl = rtrim($baseUrl, '/');
define('BASE_URL', $baseUrl);

function url($path = '')
{
    $p = '/' . ltrim($path, '/');
    return (BASE_URL === '/' || BASE_URL === '') ? $p : BASE_URL . $p;
}

function db()
{
    static $p;
    if (!$p)
        $p = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    return $p;
}
