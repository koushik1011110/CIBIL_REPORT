<?php 
require_once __DIR__.'/../includes/layout.php';
role('staff');
$p = db();
$q = $p->prepare('SELECT * FROM customers WHERE shop_id=? ORDER BY id DESC');
$q->execute([(int)u()['shop_id']]);
$rows = $q->fetchAll();

start('Customers');
?>
<div class="card" style="display:flex; justify-content:space-between; align-items:center;">
    <h3 style="margin:0; font-size:1.1rem; color:#fff;">Customer Management</h3>
    <a class="btn" href="customer-create.php">+ Add Customer</a>
</div>
<br>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>PAN</th>
                <th>Score</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($rows)): ?>
                <tr><td colspan="6" style="text-align:center; padding:16px;" class="muted">No customers registered yet.</td></tr>
            <?php else: ?>
                <?php foreach($rows as $r): ?>
                    <tr>
                        <td><strong><?=e($r['name'])?></strong></td>
                        <td><?=e($r['mobile'])?></td>
                        <td><?=e($r['email'])?></td>
                        <td><?=e($r['pan'])?></td>
                        <td><?=e($r['credit_score'] ?: '-')?></td>
                        <td>
                            <a class="btn" style="padding:4px 10px; font-size:0.8rem; background:var(--primary);" href="customer-edit.php?id=<?=$r['id']?>">✏️ Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_end(); ?>
