<?php 
require_once __DIR__.'/../includes/layout.php';
role('superadmin');

$p = db();
$q = $p->query('
    SELECT f.*, c.name as customer_name, c.mobile as customer_mobile, p.name as product_name, s.name as shop_name 
    FROM finance_applications f 
    JOIN customers c ON c.id = f.customer_id 
    LEFT JOIN products p ON p.id = f.product_id 
    LEFT JOIN shops s ON s.id = f.shop_id 
    ORDER BY f.id DESC
');
$rows = $q->fetchAll();

start('All Finance Applications (Admin)');
?>
<div class="card" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <h3 style="font-size: 1.1rem; font-weight: 800; color: #fff;">Global Finance Applications</h3>
        <p class="muted" style="margin-top: 4px;">Super admin oversight of all store loan applications</p>
    </div>
    <a href="credit-check.php" class="btn"><i data-lucide="plus-circle"></i> + New Application</a>
</div>

<div class="card">
    <table class="table">
        <thead>
            <tr>
                <th>App No</th>
                <th>Shop</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Financed Amount</th>
                <th>Tenure & EMI</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($rows)): ?>
                <tr><td colspan="7" style="text-align: center;">No finance applications found.</td></tr>
            <?php else: ?>
                <?php foreach($rows as $r): ?>
                    <tr>
                        <td><strong><?=e($r['application_no'])?></strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=e($r['created_at'])?></span></td>
                        <td><strong><?=e($r['shop_name'] ?: 'Demo Store')?></strong></td>
                        <td><strong><?=e($r['customer_name'])?></strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=e($r['customer_mobile'])?></span></td>
                        <td><?=e($r['product_name'] ?: 'Mobile Product')?></td>
                        <td><strong style="color:var(--primary);"><?=money($r['finance_amount'])?></strong></td>
                        <td><strong><?=money($r['emi'])?>/mo</strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=e($r['tenure'])?> Months @ <?=e($r['interest_rate'])?>%</span></td>
                        <td><span class="badge <?=$r['status']==='approved'||$r['status']==='active'?'badge-success':'badge-warning'?>"><?=e(strtoupper($r['status']))?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_end(); ?>
