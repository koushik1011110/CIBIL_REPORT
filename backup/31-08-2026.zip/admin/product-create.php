<?php 
require_once __DIR__.'/../includes/layout.php';
role('superadmin');

$shops = db()->query('SELECT id, name FROM shops WHERE status="active" ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = db()->prepare('INSERT INTO products (shop_id, name, brand, model, sku, category, selling_price, stock, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $s->execute([
        $_POST['shop_id'] ?: 1,
        $_POST['name'],
        $_POST['brand'] ?: null,
        $_POST['model'] ?: null,
        $_POST['sku'] ?: 'SKU-' . rand(1000, 9999),
        $_POST['category'] ?: 'Mobile',
        $_POST['selling_price'] ?: 0,
        $_POST['stock'] ?: 0,
        $_POST['status'] ?: 'active'
    ]);
    header('Location: products.php');
    exit;
}

start('Add Product (Admin)');
?>
<div class="card">
    <form class="form" method="post">
        <div class="form-grid">
            <div class="field">
                <label>Assign Shop</label>
                <select name="shop_id" required>
                    <?php foreach($shops as $shop): ?>
                        <option value="<?=$shop['id']?>"><?=e($shop['name'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label>Product Name</label>
                <input name="name" placeholder="e.g. iPhone 15 Pro (256GB)" required>
            </div>
            <div class="field">
                <label>Brand</label>
                <input name="brand" placeholder="e.g. Apple / Samsung">
            </div>
            <div class="field">
                <label>Model</label>
                <input name="model" placeholder="e.g. 15 Pro">
            </div>
            <div class="field">
                <label>SKU / Serial No</label>
                <input name="sku" placeholder="e.g. SKU9081">
            </div>
            <div class="field">
                <label>Category</label>
                <select name="category">
                    <option value="Mobile">Mobile</option>
                    <option value="Laptop">Laptop</option>
                    <option value="Computer">Computer</option>
                    <option value="Tablet">Tablet</option>
                    <option value="Accessory">Accessory</option>
                </select>
            </div>
            <div class="field">
                <label>Selling Price (₹)</label>
                <input name="selling_price" type="number" step="0.01" placeholder="e.g. 120000" required>
            </div>
            <div class="field">
                <label>Stock Quantity</label>
                <input name="stock" type="number" value="10" required>
            </div>
            <div class="field">
                <label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>
        <div style="margin-top: 20px; display: flex; gap: 12px;">
            <button class="btn"><i data-lucide="check"></i> Save Product</button>
            <a class="btn" style="background: rgba(255,255,255,0.1);" href="products.php">Cancel</a>
        </div>
    </form>
</div>
<?php render_end(); ?>
