<?php 
require_once __DIR__.'/../includes/layout.php';
role('superadmin');

$p = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'theme_mode' => $_POST['theme_mode'] ?? 'dark',
        'emi_payu_key' => trim($_POST['emi_payu_key'] ?? ''),
        'emi_payu_salt' => trim($_POST['emi_payu_salt'] ?? ''),
        'emi_payu_env' => $_POST['emi_payu_env'] ?? 'production',
    ];

    foreach ($settings as $key => $val) {
        $stmt = $p->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->execute([$key, $val]);
    }

    header('Location: settings.php?msg=saved');
    exit;
}

$themeMode  = get_setting('theme_mode', 'dark');
$emiPayuKey  = get_setting('emi_payu_key', PAYU_MERCHANT_KEY);
$emiPayuSalt = get_setting('emi_payu_salt', PAYU_SALT);
$emiPayuEnv  = get_setting('emi_payu_env', PAYU_ENV);

start('System Settings & Gateway Config');
?>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'saved'): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid var(--success); color: var(--success); padding: 14px 18px; border-radius: 12px; margin-bottom: 20px;">
        <strong>✓ Settings Saved!</strong> System theme mode & EMI payment gateway credentials updated successfully in database.
    </div>
<?php endif; ?>

<form method="post">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px; margin-bottom: 24px;">
        
        <!-- THEME SELECTION CARD -->
        <div class="card">
            <h3 style="font-size: 1.1rem; font-weight: 800; color: #fff; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
                <i data-lucide="sun" style="color: var(--warning);"></i> ERP Theme Customization
            </h3>

            <div class="field" style="margin-bottom: 16px;">
                <label>Select System Appearance Theme Mode *</label>
                <select name="theme_mode" style="width: 100%; padding: 12px; font-size: 0.9rem;">
                    <option value="dark" <?=$themeMode === 'dark' ? 'selected' : ''?>>🌙 Dark Mode (Sleek Dark Cyber Design)</option>
                    <option value="light" <?=$themeMode === 'light' ? 'selected' : ''?>>☀️ Light Mode (Clean Executive Design)</option>
                </select>
            </div>
            <p class="muted" style="font-size: 0.82rem;">Applies system-wide UI theme across Superadmin, Shop Admin, Staff, and Customer Portals.</p>
        </div>

        <!-- EMI PAYMENT GATEWAY CONFIG CARD -->
        <div class="card">
            <h3 style="font-size: 1.1rem; font-weight: 800; color: #fff; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
                <i data-lucide="credit-card" style="color: var(--primary);"></i> EMI Payment Gateway Credentials (DB Powered)
            </h3>

            <div class="field" style="margin-bottom: 14px;">
                <label>PayU Merchant Key (for EMI & Loan Collections)</label>
                <input name="emi_payu_key" value="<?=e($emiPayuKey)?>" placeholder="Enter PayU Key" required style="width: 100%; padding: 10px;">
            </div>

            <div class="field" style="margin-bottom: 14px;">
                <label>PayU Merchant Salt</label>
                <input name="emi_payu_salt" type="password" value="<?=e($emiPayuSalt)?>" placeholder="Enter PayU Salt" required style="width: 100%; padding: 10px;">
            </div>

            <div class="field" style="margin-bottom: 16px;">
                <label>Payment Gateway Environment</label>
                <select name="emi_payu_env" style="width: 100%; padding: 10px;">
                    <option value="production" <?=$emiPayuEnv === 'production' ? 'selected' : ''?>>LIVE / Production Mode</option>
                    <option value="test" <?=$emiPayuEnv === 'test' ? 'selected' : ''?>>TEST / Sandbox Mode</option>
                </select>
            </div>
        </div>

    </div>

    <!-- NOTICE CARD FOR WALLET TOPUP GATEWAY -->
    <div class="card" style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--primary); margin-bottom: 24px; padding: 20px;">
        <div style="display: flex; gap: 12px; align-items: flex-start;">
            <i data-lucide="info" style="color: var(--primary); width: 24px; height: 24px; flex-shrink: 0; margin-top: 2px;"></i>
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                <strong style="color: #fff;">Wallet Topup Gateway Notice:</strong><br>
                Shop Admin & Staff wallet top-up payments use default developer PayU credentials in <code>config.php</code> by design, so topup money routes directly to the developer account. EMI collections use the custom database settings configured above.
            </div>
        </div>
    </div>

    <button type="submit" class="btn" style="padding: 14px 28px; font-size: 0.95rem; background: linear-gradient(135deg, var(--primary), #1d4ed8);">
        <i data-lucide="save"></i> Save Settings & Gateway Config
    </button>
</form>

<?php render_end(); ?>
