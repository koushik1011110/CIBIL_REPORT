<?php 
require_once __DIR__.'/../includes/layout.php';
role('superadmin');

$p = db();
$q = $p->query('SELECT p.*, s.name as shop_name FROM products p LEFT JOIN shops s ON s.id=p.shop_id ORDER BY p.id DESC');
$rows = $q->fetchAll();

start('All Products Catalog (Admin)');
?>
<div class="card" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <h3 style="font-size: 1.1rem; font-weight: 800; color: #fff;">System Product Inventory</h3>
        <p class="muted" style="margin-top: 4px;">Super admin control over all store products</p>
    </div>
    <a class="btn" href="product-create.php"><i data-lucide="plus-circle"></i> Add New Product</a>
</div>

<div class="card">
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Shop Name</th>
                <th>Product Name</th>
                <th>Brand / Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($rows)): ?>
                <tr><td colspan="7" style="text-align: center;">No products found in system.</td></tr>
            <?php else: ?>
                <?php foreach($rows as $idx => $r): ?>
                    <tr>
                        <td><?=$idx + 1?></td>
                        <td><strong><?=e($r['shop_name'] ?: 'Demo Store')?></strong></td>
                        <td><strong><?=e($r['name'])?></strong></td>
                        <td><?=e($r['brand'])?> <span class="badge badge-info"><?=e($r['category'])?></span></td>
                        <td><strong style="color:var(--primary);"><?=money($r['selling_price'])?></strong></td>
                        <td><?=e($r['stock'])?> units</td>
                        <td><span class="badge <?=$r['status']==='active'?'badge-success':'badge-warning'?>"><?=e($r['status'])?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_end(); ?>
