<?php
require_once __DIR__ . '/../includes/auth.php';
role('superadmin', 'shop_admin', 'staff');

$financeId = isset($_POST['finance_id']) ? (int)$_POST['finance_id'] : 0;
$emiId     = isset($_POST['emi_id']) ? (int)$_POST['emi_id'] : 0;
$amount    = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$remarks   = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';

$db = db();
$userId = (int)u()['id'];

if ($emiId > 0 && $financeId <= 0) {
    $stmtEmi = $db->prepare('SELECT finance_id FROM emi_schedules WHERE id = ?');
    $stmtEmi->execute([$emiId]);
    $financeId = (int)$stmtEmi->fetchColumn();
}

if ($financeId <= 0 || $amount <= 0) {
    header('Location: ' . $_SERVER['HTTP_REFERER'] . '?msg=invalid');
    exit;
}

try {
    // Fetch Finance Application
    $stmtApp = $db->prepare('SELECT * FROM finance_applications WHERE id = ?');
    $stmtApp->execute([$financeId]);
    $app = $stmtApp->fetch();

    if (!$app) {
        header('Location: ' . $_SERVER['HTTP_REFERER'] . '?msg=notfound');
        exit;
    }

    $isDownPayment = (isset($_POST['is_downpayment']) && $_POST['is_downpayment'] == 1) || ($app['status'] === 'pending' && $emiId === 0);

    // Approve application if it is pending
    if ($app['status'] === 'pending') {
        $db->prepare("UPDATE finance_applications SET status = 'approved' WHERE id = ?")->execute([$financeId]);
    }

    $installmentNo = null;
    $dueDateStr = '';

    if ($isDownPayment) {
        if (empty($remarks)) {
            $remarks = 'Down Payment Received (Application Approved)';
        }
    } else {
        // Identify target EMI
        if ($emiId > 0) {
            $db->prepare("UPDATE emi_schedules SET status = 'paid', paid_amount = ?, paid_at = NOW() WHERE id = ?")->execute([$amount, $emiId]);
            $eStmt = $db->prepare("SELECT installment_no, due_date FROM emi_schedules WHERE id = ?");
            $eStmt->execute([$emiId]);
            $eData = $eStmt->fetch();
            if ($eData) {
                $installmentNo = $eData['installment_no'];
                $dueDateStr = date('M Y', strtotime($eData['due_date']));
            }
        } else {
            $eStmt = $db->prepare("SELECT id, installment_no, due_date FROM emi_schedules WHERE finance_id = ? AND status != 'paid' ORDER BY installment_no ASC LIMIT 1");
            $eStmt->execute([$financeId]);
            $eData = $eStmt->fetch();
            if ($eData) {
                $emiId = $eData['id'];
                $installmentNo = $eData['installment_no'];
                $dueDateStr = date('M Y', strtotime($eData['due_date']));
                $db->prepare("UPDATE emi_schedules SET status = 'paid', paid_amount = ?, paid_at = NOW() WHERE id = ?")->execute([$amount, $emiId]);
            }
        }

        if (empty($remarks)) {
            $remarks = 'Cash Payment' . ($installmentNo ? " for Installment #{$installmentNo} ({$dueDateStr})" : '');
        }
    }

    // Insert Payment Record
    $refNo = 'MAN' . time() . rand(100, 999);
    $stmtPay = $db->prepare("INSERT INTO payments (finance_id, emi_id, customer_id, amount, payment_method, reference_no, remarks, paid_at, recorded_by) VALUES (?, ?, ?, ?, 'Cash', ?, ?, NOW(), ?)");
    $stmtPay->execute([
        $financeId,
        $emiId > 0 ? $emiId : null,
        $app['customer_id'],
        $amount,
        $refNo,
        $remarks,
        $userId
    ]);

    header('Location: ' . $_SERVER['HTTP_REFERER'] . '?msg=paid_success');
    exit;

} catch (Exception $e) {
    header('Location: ' . $_SERVER['HTTP_REFERER'] . '?msg=error&err=' . urlencode($e->getMessage()));
    exit;
}
