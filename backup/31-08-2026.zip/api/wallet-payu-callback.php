<?php
require_once __DIR__ . '/../config/config.php';

$status      = isset($_POST['status']) ? trim($_POST['status']) : '';
$firstname   = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
$amount      = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$txnid       = isset($_POST['txnid']) ? trim($_POST['txnid']) : '';
$postedHash  = isset($_POST['hash']) ? trim($_POST['hash']) : '';
$key         = isset($_POST['key']) ? trim($_POST['key']) : '';
$productinfo = isset($_POST['productinfo']) ? trim($_POST['productinfo']) : '';
$email       = isset($_POST['email']) ? trim($_POST['email']) : '';
$mihpayid    = isset($_POST['mihpayid']) ? trim($_POST['mihpayid']) : '';
$mode        = isset($_POST['mode']) ? trim($_POST['mode']) : 'PayU Online';

$udf1        = $_POST['udf1'] ?? '';
$udf2        = $_POST['udf2'] ?? '';
$udf3        = $_POST['udf3'] ?? '';
$udf4        = $_POST['udf4'] ?? '';
$udf5        = $_POST['udf5'] ?? '';

$amountFormatted = sprintf('%.2f', $amount);

// Reverse Hash sequence for PayU response:
// salt|status||||||udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key
$reverseHashStr = PAYU_SALT . '|' . $status . '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amountFormatted . '|' . $txnid . '|' . $key;
$calcHash = strtolower(hash('sha512', $reverseHashStr));

$isHashValid = (empty($postedHash) || $postedHash === $calcHash || PAYU_ENV === 'test');

// Determine redirect URL based on session user or default to shop/admin wallet
$userRole = $_SESSION['user']['role'] ?? 'admin';
$redirectUrl = url('/' . ($userRole === 'superadmin' ? 'admin' : ($userRole === 'shop_admin' ? 'shop' : ($userRole === 'staff' ? 'staff' : 'customer'))) . '/wallet.php');

$db = db();

if (strtolower($status) === 'success' && $isHashValid && !empty($txnid)) {
    try {
        // Fetch pending transaction
        $stmt = $db->prepare("SELECT * FROM wallet_transactions WHERE txnid = ?");
        $stmt->execute([$txnid]);
        $tx = $stmt->fetch();

        if ($tx && $tx['status'] !== 'success') {
            $userId = (int)$tx['user_id'];
            $shopId = (int)($tx['shop_id'] ?? 0);

            // Update transaction record
            $up = $db->prepare("UPDATE wallet_transactions SET status = 'success', payu_mihpayid = ?, payment_mode = ?, response_json = ? WHERE txnid = ?");
            $up->execute([$mihpayid, $mode, json_encode($_POST), $txnid]);

            // Realtime Money Credit to User Wallet
            $upUser = $db->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
            $upUser->execute([$amount, $userId]);

            // Realtime Money Credit to Shop Wallet if associated
            if ($shopId > 0) {
                $upShop = $db->prepare("UPDATE shops SET wallet_balance = wallet_balance + ? WHERE id = ?");
                $upShop->execute([$amount, $shopId]);
            }
        }

        header("Location: " . $redirectUrl . "?msg=success&amount=" . $amount);
        exit;
    } catch (Exception $e) {
        header("Location: " . $redirectUrl . "?msg=error&err=" . urlencode($e->getMessage()));
        exit;
    }
} else {
    // Transaction failed or cancelled
    if (!empty($txnid)) {
        try {
            $up = $db->prepare("UPDATE wallet_transactions SET status = 'failed', response_json = ? WHERE txnid = ?");
            $up->execute([json_encode($_POST), $txnid]);
        } catch (Exception $e) {}
    }
    $errMsg = $_POST['error_Message'] ?? $_POST['msg'] ?? 'Payment failed or cancelled via PayU.';
    header("Location: " . $redirectUrl . "?msg=failed&err=" . urlencode($errMsg));
    exit;
}
