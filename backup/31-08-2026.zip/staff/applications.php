<?php 
require_once __DIR__.'/../includes/layout.php';
role('staff');

$p = db();
$sid = (int)(u()['shop_id'] ?: 1);

$q = $p->prepare('
    SELECT f.*, c.name as customer_name, c.mobile as customer_mobile, p.name as product_name 
    FROM finance_applications f 
    JOIN customers c ON c.id = f.customer_id 
    LEFT JOIN products p ON p.id = f.product_id 
    WHERE f.shop_id = ? 
    ORDER BY f.id DESC
');
$q->execute([$sid]);
$rows = $q->fetchAll();

start('Finance Applications');
?>

<?php if (isset($_GET['msg'])): ?>
    <?php if ($_GET['msg'] === 'paid_success' || $_GET['msg'] === 'success'): ?>
        <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid var(--success); color: var(--success); padding: 14px 18px; border-radius: 12px; margin-bottom: 20px;">
            <strong>✓ Success!</strong> Payment recorded & Finance Application status updated to Approved/Active.
        </div>
    <?php endif; ?>
<?php endif; ?>

<div class="card" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h3 style="font-size: 1.1rem; font-weight: 800; color: #fff;">Finance & EMI Applications</h3>
        <p class="muted" style="margin-top: 4px;">Track loan approvals, PayU 1st installment/mandate, and cash collection</p>
    </div>
    <a href="credit-check.php" class="btn"><i data-lucide="plus-circle"></i> + New Application</a>
</div>

<div class="card" style="padding: 0; overflow-x: auto;">
    <table class="table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
        <thead>
            <tr style="background: rgba(15,23,42,0.6); color: var(--text-muted);">
                <th style="padding: 12px;">App No</th>
                <th style="padding: 12px;">Customer</th>
                <th style="padding: 12px;">Product</th>
                <th style="padding: 12px;">Price / Down Payment</th>
                <th style="padding: 12px;">Financed Amount</th>
                <th style="padding: 12px;">Tenure & EMI</th>
                <th style="padding: 12px;">Status</th>
                <th style="padding: 12px;">Actions / Approval</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($rows)): ?>
                <tr><td colspan="8" style="text-align: center; padding: 20px;">No finance applications found.</td></tr>
            <?php else: ?>
                <?php foreach($rows as $r): ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 12px;"><strong><?=e($r['application_no'])?></strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=date('d M Y, h:i A', strtotime($r['created_at']))?></span></td>
                        <td style="padding: 12px;"><strong><?=e($r['customer_name'])?></strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=e($r['customer_mobile'])?></span></td>
                        <td style="padding: 12px;"><?=e($r['product_name'] ?: 'Mobile Product')?></td>
                        <td style="padding: 12px;"><?=money($r['product_price'])?><br><span style="font-size:0.75rem; color:var(--text-muted);">Down: <?=money($r['down_payment'])?></span></td>
                        <td style="padding: 12px;"><strong style="color:var(--primary);"><?=money($r['finance_amount'])?></strong></td>
                        <td style="padding: 12px;"><strong><?=money($r['emi'])?>/mo</strong><br><span style="font-size:0.75rem; color:var(--text-muted);"><?=e($r['tenure'])?> Months @ <?=e($r['interest_rate'])?>%</span></td>
                        <td style="padding: 12px;">
                            <?php if ($r['status'] === 'approved' || $r['status'] === 'active'): ?>
                                <span class="badge badge-success">APPROVED</span>
                            <?php else: ?>
                                <span class="badge badge-warning">PENDING (REQUIRES DOWN PAYMENT)</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 12px;">
                            <?php if ($r['status'] === 'pending'): ?>
                                <form action="<?=url('/api/manual-pay-emi.php')?>" method="POST" style="display:inline;">
                                    <input type="hidden" name="finance_id" value="<?=$r['id']?>">
                                    <input type="hidden" name="amount" value="<?=$r['down_payment']?>">
                                    <input type="hidden" name="is_downpayment" value="1">
                                    <button type="submit" class="btn" style="padding: 8px 14px; font-size: 0.8rem; background: linear-gradient(135deg, var(--success), #059669); color: #fff;" onclick="return confirm('Approve application upon receiving Down Payment Cash of <?=money($r['down_payment'])?>?')">
                                        💵 Receive Down Payment (<?=money($r['down_payment'])?> Cash) & Approve
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="font-size: 0.8rem; color: var(--success); font-weight: 700;">✓ Active / Approved</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php render_end(); ?>
