<?php 
require_once __DIR__.'/../includes/layout.php';
role('customer');

$p = db();
$user = u();

// Robust Customer Lookup by Email, Mobile, extracted Mobile, or Name
$userEmail = $user['email'] ?? '';
$userName = $user['name'] ?? '';
$mobileFromEmail = str_replace('@customer.local', '', $userEmail);

$s = $p->prepare('
    SELECT * FROM customers 
    WHERE (email != "" AND email = ?) 
       OR (mobile != "" AND (mobile = ? OR mobile = ?)) 
       OR name = ? 
    LIMIT 1
');
$s->execute([$userEmail, $userEmail, $mobileFromEmail, $userName]);
$c = $s->fetch() ?: [];
$customerId = (int)($c['id'] ?? 0);

// Fetch Latest Application
$f = null;
$totalFinanced = 0;
$totalPayable = 0;
$totalPaid = 0;
$pendingBalance = 0;
$nextEmi = null;
$paidPercentage = 0;

if ($customerId > 0) {
    $fStmt = $p->prepare('SELECT * FROM finance_applications WHERE customer_id=? ORDER BY id DESC LIMIT 1');
    $fStmt->execute([$customerId]);
    $f = $fStmt->fetch() ?: null;

    if ($f) {
        $totalFinanced = floatval($f['finance_amount']);
        $totalPayable = floatval($f['total_payable']);

        // Calculate total paid from payments
        $pStmt = $p->prepare('SELECT SUM(amount) FROM payments WHERE customer_id=? OR finance_id=?');
        $pStmt->execute([$customerId, $f['id']]);
        $totalPaid = floatval($pStmt->fetchColumn() ?: 0);

        $pendingBalance = max(0, $totalPayable - $totalPaid);

        if ($totalPayable > 0) {
            $paidPercentage = min(100, max(0, round(($totalPaid / $totalPayable) * 100, 1)));
        }

        // Fetch Next EMI Due Date
        $eStmt = $p->prepare('SELECT * FROM emi_schedules WHERE finance_id=? AND status != "paid" ORDER BY installment_no ASC LIMIT 1');
        $eStmt->execute([$f['id']]);
        $nextEmi = $eStmt->fetch() ?: null;
    }
}

// Color logic according to exact user instructions:
// < 25%: Orange / Red
// 25% - 74.9%: Yellow
// 75% - 99.9%: Blue
// 100%: Green

$barColor = '#f97316'; // Orange / Red below 25%
$badgeClass = 'badge-danger';
$statusLabel = 'Below 25% Cleared';

if ($paidPercentage >= 100) {
    $barColor = '#10b981'; // Green
    $badgeClass = 'badge-success';
    $statusLabel = '100% Fully Paid & Cleared';
} elseif ($paidPercentage >= 75) {
    $barColor = '#3b82f6'; // Blue
    $badgeClass = 'badge-info';
    $statusLabel = '75%+ Progress (Blue Tier)';
} elseif ($paidPercentage >= 25) {
    $barColor = '#eab308'; // Yellow
    $badgeClass = 'badge-warning';
    $statusLabel = '25%+ Progress (Yellow Tier)';
} else {
    $barColor = '#f97316'; // Orange / Red
    $badgeClass = 'badge-danger';
    $statusLabel = 'Below 25% Cleared (Orange/Red)';
}

start('Customer Dashboard');
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 1.4rem; font-weight: 800; color: #fff;">Welcome back, <?=e(!empty($c['name']) ? $c['name'] : ($user['name'] ?? 'Customer'))?>! 👋</h2>
    <p class="muted" style="margin-top: 4px;">Track your active store loans, EMI schedule, and payment history</p>
</div>

<!-- METRIC OVERVIEW CARDS -->
<div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 24px;">
    <div class="card">
        <div class="muted">Credit Score</div>
        <div class="metric" style="color: var(--success);"><?=!empty($c['credit_score']) ? $c['credit_score'] : '—'?></div>
        <small class="muted">Bureau Assessment Rating</small>
    </div>

    <div class="card">
        <div class="muted">Total Financed Loan</div>
        <div class="metric"><?=money($totalFinanced)?></div>
        <small class="muted"><?=e($f['application_no'] ?? 'No active loan')?></small>
    </div>

    <div class="card">
        <div class="muted">Total Amount Paid</div>
        <div class="metric" style="color: var(--success);"><?=money($totalPaid)?></div>
        <small class="muted">Cleared Installments</small>
    </div>

    <div class="card">
        <div class="muted">Pending Outstanding</div>
        <div class="metric" style="color: var(--danger);"><?=money($pendingBalance)?></div>
        <small class="muted">Remaining Balance</small>
    </div>
</div>

<!-- DYNAMIC LOAN REPAYMENT PROGRESS LINE CARD -->
<?php if ($f): ?>
    <div class="card" style="margin-bottom: 24px; padding: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px;">
            <div>
                <h3 style="font-size: 1.15rem; font-weight: 800; color: #fff;">📊 Loan Repayment Progress</h3>
                <p class="muted" style="margin-top: 2px;">Track your total cleared percentage against loan payable amount</p>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span class="badge <?=$badgeClass?>" style="font-size: 0.85rem; padding: 6px 14px;"><?=$statusLabel?></span>
                <span style="font-size: 1.4rem; font-weight: 800; color: <?=$barColor?>;"><?=$paidPercentage?>%</span>
            </div>
        </div>

        <!-- DYNAMIC PROGRESS TRACK LINE -->
        <div style="background: rgba(15, 23, 42, 0.8); border: 1px solid var(--border-color); height: 22px; border-radius: 12px; overflow: hidden; position: relative; padding: 3px;">
            <div style="height: 100%; width: <?=$paidPercentage?>%; background: <?=$barColor?>; border-radius: 8px; transition: width 0.8s ease-in-out; box-shadow: 0 0 12px <?=$barColor?>;"></div>
        </div>

        <!-- DETAILS SUMMARY FOOTER -->
        <div style="margin-top: 18px; padding-top: 14px; border-top: 1px solid var(--border-color); display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px; font-size: 0.85rem;">
            <div>Total Loan Payable: <strong style="color: #fff;"><?=money($totalPayable)?></strong></div>
            <div>Amount Paid: <strong style="color: var(--success);"><?=money($totalPaid)?></strong></div>
            <div>Remaining Balance: <strong style="color: var(--danger);"><?=money($pendingBalance)?></strong></div>
        </div>
    </div>
<?php endif; ?>

<!-- NEXT EMI DUE ALERT CARD -->
<?php if ($nextEmi && $f): ?>
    <div class="card" style="background: linear-gradient(135deg, rgba(30, 41, 59, 0.9), rgba(15, 23, 42, 0.95)); border: 1px solid var(--primary); margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
            <span class="badge badge-warning">UPCOMING EMI DUE</span>
            <h3 style="font-size: 1.2rem; font-weight: 800; color: #fff; margin-top: 6px;">Next EMI Installment #<?=$nextEmi['installment_no']?>: <?=money($nextEmi['amount'])?></h3>
            <p class="muted" style="margin-top: 4px;">Due Date: <strong style="color: #60a5fa;"><?=date('d M Y', strtotime($nextEmi['due_date']))?></strong></p>
        </div>
        <div>
            <a href="<?=url('/api/pay-installment.php?finance_id=' . $f['id'] . '&emi_id=' . $nextEmi['id'])?>" class="btn" style="background: linear-gradient(135deg, var(--primary), #1d4ed8); font-size: 0.95rem; padding: 12px 20px;">
                💳 Pay EMI Online Now via PayU
            </a>
        </div>
    </div>
<?php endif; ?>

<?php render_end(); ?>
