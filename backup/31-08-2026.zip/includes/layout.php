<?php require_once __DIR__.'/auth.php'; 
function start($title){
    $x = u();
    $roleName = strtoupper(str_replace('_', ' ', $x['role'] ?? 'USER'));
    $initials = strtoupper(substr($x['name'] ?? 'U', 0, 2));
    $shopName = 'Demo Mobile Store';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=e($title)?> · GO4FIN (Go4 Finance Private Limited)</title>
    
    <!-- Google Fonts & Lucide Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    
    <link rel="stylesheet" href="<?=url('/public/assets/css/app.css')?>">
</head>
<?php $themeMode = get_setting('theme_mode', 'dark'); ?>
<body class="<?=$themeMode === 'light' ? 'light-theme' : ''?>">

    <!-- NAVBAR -->
    <header class="navbar">
        <div style="display: flex; align-items: center; gap: 16px;">
            <button style="background:transparent; border:none; color:#fff; font-size:1.4rem; cursor:pointer;" onclick="document.querySelector('aside').classList.toggle('open')">☰</button>
            <a href="<?=url('/')?>" class="brand">
                <div class="brand-logo">G4F</div>
                <div class="brand-name">GO4<span style="color: var(--primary);">FIN</span></div>
                <span class="brand-badge"><?=$roleName?></span>
            </a>
        </div>

        <div class="nav-actions">
            <div class="user-profile-btn">
                <div class="avatar"><?=$initials?></div>
                <div class="user-info">
                    <span class="user-name"><?=e($x['name'] ?? 'User')?></span>
                    <span class="user-role-title"><?=$roleName?></span>
                </div>
            </div>
        </div>
    </header>

    <div class="app-wrapper">
        <!-- SIDEBAR NAVIGATION -->
        <aside>
            <nav>
                <?php $base = url($x['role']==='superadmin' ? '/admin' : ($x['role']==='shop_admin' ? '/shop' : ($x['role']==='staff' ? '/staff' : '/customer'))); ?>
                
                <a href="<?=$base?>/dashboard.php"><i data-lucide="layout-dashboard"></i> Dashboard</a>
                
                <?php if($x['role'] !== 'customer'): ?>
                    <a href="<?=$base?>/customers.php"><i data-lucide="users"></i> Customers</a>
                    <a href="<?=$base?>/credit-check.php"><i data-lucide="shield-check"></i> Credit Check</a>
                    <a href="<?=$base?>/applications.php"><i data-lucide="file-text"></i> Applications</a>
                    <a href="<?=$base?>/products.php"><i data-lucide="package"></i> Products</a>
                    <a href="<?=$base?>/collections.php"><i data-lucide="wallet"></i> Collections</a>
                    <a href="<?=$base?>/wallet.php"><i data-lucide="credit-card"></i> Wallet PayU</a>
                <?php else: ?>
                    <a href="<?=url('/customer/finance.php')?>"><i data-lucide="wallet"></i> My Store Loans</a>
                    <a href="<?=url('/customer/emi-schedule.php')?>"><i data-lucide="calendar"></i> EMI Schedule</a>
                    <a href="<?=url('/customer/payments.php')?>"><i data-lucide="credit-card"></i> Payment Receipts</a>
                    <a href="<?=url('/customer/credit-report.php')?>"><i data-lucide="file-spreadsheet"></i> Credit Bureau Report</a>
                <?php endif; ?>
                
                <?php if($x['role'] === 'superadmin'): ?>
                    <a href="<?=url('/admin/shops.php')?>"><i data-lucide="store"></i> Shops</a>
                    <a href="<?=url('/admin/users.php')?>"><i data-lucide="user-check"></i> Users</a>
                    <a href="<?=url('/admin/settings.php')?>"><i data-lucide="sliders"></i> Settings</a>
                <?php endif; ?>
                
                <a href="<?=url('/logout.php')?>" style="margin-top: auto; color: var(--danger);"><i data-lucide="log-out"></i> Logout</a>
            </nav>
        </aside>

        <!-- MAIN CONTENT AREA -->
        <main>
            <header class="page-header">
                <h1><?=e($title)?></h1>
            </header>
            <section>
<?php } 

function render_end(){ ?>
            </section>
        </main>
    </div>

    <script>
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    </script>
</body>
</html>
<?php } 
if(!function_exists('end')){ function end(){ render_end(); } } 
?>
