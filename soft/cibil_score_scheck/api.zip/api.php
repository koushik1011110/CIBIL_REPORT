<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid Request Method. Use POST."]);
    exit;
}

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true);

if (!$input) {
    $input = $_POST;
}

$name     = isset($input['name']) ? trim($input['name']) : '';
$mobile   = isset($input['mobile']) ? trim($input['mobile']) : '';
$fetchBy  = isset($input['fetch_by']) ? trim($input['fetch_by']) : '';
$number   = isset($input['number']) ? trim($input['number']) : '';
$orderId  = isset($input['orderid']) && !empty($input['orderid']) ? trim($input['orderid']) : 'TXN' . time() . rand(1000, 9999);

if (empty($name) || empty($mobile) || empty($fetchBy) || empty($number)) {
    echo json_encode(["status" => "error", "message" => "Required parameters missing: name, mobile, fetch_by, number."]);
    exit;
}

$postFields = [
    'api_key'  => FINPAY_API_KEY,
    'orderid'  => $orderId,
    'name'     => $name,
    'number'   => $number,
    'fetch_by' => $fetchBy,
    'mobile'   => $mobile
];

$ch = curl_init(FINPAY_API_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);

$response = curl_exec($ch);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    echo json_encode(["status" => "error", "message" => "cURL Error: " . $curlError]);
    exit;
}

$responseData = json_decode($response, true);
$creditScore = null;
$apiStatus = 'failed';

if ($responseData) {
    if (isset($responseData['credit_score'])) {
        $creditScore = intval($responseData['credit_score']);
    } elseif (isset($responseData['data']['credit_score'])) {
        $creditScore = intval($responseData['data']['credit_score']);
    } elseif (isset($responseData['score'])) {
        $creditScore = intval($responseData['score']);
    }

    if (isset($responseData['status'])) {
        $apiStatus = is_bool($responseData['status']) ? ($responseData['status'] ? 'success' : 'failed') : strtolower((string)$responseData['status']);
    } elseif (isset($responseData['response_code']) && $responseData['response_code'] == 200) {
        $apiStatus = 'success';
    }
}

try {
    $conn = getDBConnection();
    $stmt = $conn->prepare("INSERT INTO credit_reports (orderid, name, mobile, fetch_by, number, credit_score, api_status, response_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $jsonStore = $response ?: json_encode(["raw_response" => $response]);
    $stmt->bind_param("sssssiss", $orderId, $name, $mobile, $fetchBy, $number, $creditScore, $apiStatus, $jsonStore);
    $stmt->execute();
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    // Database save failure shouldn't stop returning API response
}

if ($responseData) {
    $responseData['orderid'] = $orderId;
    echo json_encode($responseData);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid API Response",
        "orderid" => $orderId,
        "raw_response" => $response
    ]);
}
